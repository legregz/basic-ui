json-ui is a project of user interface using pygame and json files. The goal is to simplify the creation of app menus, and interfaces.
