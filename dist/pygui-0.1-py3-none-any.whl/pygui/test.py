import pyui, pygame

screen = pygame.display.set_mode()

pyui.setComponents("components.json")
menu = pyui.Page(screen, "page.json")

run = True
while run == True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    screen.fill(pyui.convertColor("f"))

    menu.show()
    pygame.display.flip()